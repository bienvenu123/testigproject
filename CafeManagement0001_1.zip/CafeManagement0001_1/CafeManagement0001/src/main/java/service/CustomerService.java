package service;

import model.Customer;

import java.util.List;
import java.util.Optional;

public interface CustomerService {
    Customer registerCustomer(Customer customer);
    Customer updateCustomer(Customer customer);
    void deleteCustomer(Customer customer);
    Optional<Customer> findCustomerById(Customer customer);
    List<Customer> customerList();
    List<Customer>  findCustomerByName(Customer customer);
}
