package service.implementation;

import dao.CustomerDao;
import model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.CustomerService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerImplementation implements CustomerService {
    private CustomerDao dao;
    @Override
    public Customer registerCustomer(Customer customer) {
        return dao.save(customer);
    }

    @Override
    public Customer updateCustomer(Customer customer) {
        Customer customerToUpdate = findCustomerById(customer).get();
        if(customerToUpdate != null){

            customerToUpdate.setCustomerName(customer.getCustomerName());
            customerToUpdate.setProductName(customer.getProductName());
            customerToUpdate.setProductPrice(customer.getProductPrice());
            return dao.save(customerToUpdate);
        }
        return dao.save(customer);
    }

    @Override
    public void deleteCustomer(Customer customer) {
        dao.deleteById(customer.getCustomerId());
    }

    @Override
    public Optional<Customer> findCustomerById(Customer customer) {
//        return dao.findById(customer.getCustomerId()).get();
        return dao.findById(customer.getCustomerId());
    }

    @Override
    public List<Customer> customerList() {
        return dao.findAll();
    }

    @Override
    public List<Customer> findCustomerByName(Customer customer) {
        List<Customer> customerList = dao.findAll();
        List<Customer> customerListByName = new ArrayList<>();
        Iterator iterator = customerList.iterator();
        while(iterator.hasNext()){
            Customer cust = (Customer) iterator.next();
            if(cust.getCustomerName().equals(customer.getCustomerName())){
                customerListByName.add(cust);
            }
        }
//        return dao.findCustomerByCustomerName(customer);
        return customerListByName;
    }
}
