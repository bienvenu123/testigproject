package com.example.CafeManagement0001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeManagement0001Application {

	public static void main(String[] args) {
		SpringApplication.run(CafeManagement0001Application.class, args);
	}

}
