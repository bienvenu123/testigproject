package controller;

import dao.CustomerDao;
import model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import service.CustomerService;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @Autowired
    private CustomerDao dao;

    public CustomerController( CustomerService customerService) {
        super();
        this.customerService = customerService;
    }

    //build create customer REST API

    @PostMapping("/save")
    public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer){
//        return new ResponseEntity<Customer>(customerService.registerCustomer(customer), HttpStatus.CREATED);
        return new ResponseEntity<Customer>(dao.save(customer), HttpStatus.CREATED);
    }

    // build GET all customer REST API
    @GetMapping
    public List<Customer> getAllCustomers(){
        return customerService.customerList();


    }
    // build get Customer by id REST API
    @GetMapping("{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable("id")String customerId){
        Customer customer = new Customer(customerId);
        return new ResponseEntity<Customer>(customerService.findCustomerById(customer).get(), HttpStatus.OK);
    }

    //build update Customer REST API
    @PutMapping("{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable("id")String id,@RequestBody Customer customer){
        Customer customerToUpdate = customer;
        customerToUpdate.setCustomerId(id);
        return new ResponseEntity<Customer>(customerService.updateCustomer(customerToUpdate), HttpStatus.OK);
    }

    //build delete Customer REST API
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable("id") String id){
        Customer customer = new Customer(id);
        customerService.deleteCustomer(customer);
        return new ResponseEntity<String>("Customer deleted successfully!.",HttpStatus.OK);


    }
}
