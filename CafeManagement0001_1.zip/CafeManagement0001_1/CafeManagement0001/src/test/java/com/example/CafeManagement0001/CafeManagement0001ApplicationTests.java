package com.example.CafeManagement0001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeManagement0001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
