package examTesting;

import dao.CustomerDao;
import model.Customer;

import static org.mockito.BDDMockito.*;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.AssertionsForClassTypes;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;
import service.implementation.CustomerImplementation;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
@ExtendWith(MockitoExtension.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CafeManagmentTest {
    @Mock
    private CustomerDao dao;
    private Customer customer;
    @InjectMocks
    private CustomerImplementation customerService;
    @BeforeEach
    public void setup(){
        customer = new Customer("001","Egide","Mango",2000.0);
        customerService.registerCustomer(customer);
    }


    @Test
    @Order(1)
    public void saveCustomer(){
        System.out.println("=========TESTING========");
        customer = new Customer("002","Egide","Mango",2000.0);
        given(dao.save(customer)).willReturn(customer);
        Customer customerSaved = customerService.registerCustomer(customer);
        Assertions.assertThat(customerSaved).isNotNull();
    }
    @Test
    @Order(2)
    public void cafeUpdated(){
        Customer cust = new Customer();
        cust.setCustomerId("002");
        cust.setCustomerName("Donatien");
        cust.setProductName("Juice");
        cust.setProductPrice(47576.56);
        given(dao.save(customer)).willReturn(customer);
        Customer custom = customerService.registerCustomer(customer);
        Assertions.assertThat(custom).isNotNull();

    }

    @Test
    @Order(3)
    public void getCustomerListTest(){
        Customer customer2 = new Customer("004","Egide","Mango",2000.0);
        given(dao.findAll()).willReturn(List.of(customer,customer2));

        List<Customer> employeeList = customerService.customerList();
        Assertions.assertThat(employeeList).isNotNull();
        Assertions.assertThat(employeeList.size()).isEqualTo(2);
    }
@Order(4)
    @Test
    public void searchEmployeeByIdTest(){
        given(dao.findById("001")).willReturn(Optional.of(customer));
        Customer savedCustomer = customerService.findCustomerById(customer).get();
        Assertions.assertThat(savedCustomer).isNotNull();
    }

    @Test
    @Order(3)
    public void deleteEmployee(){
        Customer cust = new Customer("002","Egide","Mango",2000.0);
        customerService.registerCustomer(cust);
        customerService.deleteCustomer(cust);
        verify(dao, times(1)).deleteById(cust.getCustomerId());
    }
//    public Customer updateCustomer(){
//        Customer customer1 = new Customer();
//        customer1.setCustomerId("002H");
//        customer1.setCustomerName("Donatien");
//        customer1.setProductName("Pome");
//        customer1.setProductPrice(3000.0);
//        boolean reslt = customerService.updateCustomer();
//        customerService.updateCustomer(customer1);
//        Assertions.assertThat(true,reslt);
//
//
//    }
}
