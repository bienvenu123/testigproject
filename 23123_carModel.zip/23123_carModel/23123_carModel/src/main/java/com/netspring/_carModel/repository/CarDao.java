package com.netspring._carModel.repository;

import com.netspring._carModel.model.Car;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


public interface CarDao extends JpaRepository<Car,String> {
}
