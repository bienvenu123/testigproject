package com.netspring._carModel.service;

import com.netspring._carModel.model.Car;

import java.util.List;

public interface CarServiceInterface {
    public Car saveCar(Car car);
    public List<Car> findAll();
    public Car findById(String plateNo);
    public    Car updateCar(Car car);
    void deleteCar(String plateNo);
}
