package com.netspring._carModel.controller;

import com.netspring._carModel.model.Car;
import com.netspring._carModel.service.CarServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/23123/cars")
public class ControllerCar {
    @Autowired

    private CarServiceInterface carServiceInterface;
    @GetMapping("/find/allCar")
    public List<Car> getAllCar(){
        return  carServiceInterface.findAll();
    }
    @PostMapping("/Car/save")
    public Car createCar(@RequestBody Car car){
        return carServiceInterface.saveCar(car);
    }
    @GetMapping("/get/car/{plateNo}")
    public ResponseEntity<Car> getCarById(@PathVariable String plateNo){
        Car car = carServiceInterface.findById(plateNo);
return ResponseEntity.ok(car);
    }
    @PutMapping("/update/car/{plateNo}")
public ResponseEntity<Car> updateCar(@PathVariable String plateNo, @RequestBody Car carDetails){
        Car updCar = carServiceInterface.findById(plateNo);


        updCar.setCarName(carDetails.getCarName());
        updCar.setCarModel(carDetails.getCarModel());
        updCar.setCarType(carDetails.getCarType());
        carServiceInterface.saveCar(updCar);
        return ResponseEntity.ok(updCar);
}
@DeleteMapping("/delete/car/{plateNo}")
public ResponseEntity<HttpStatus> deleteCar(@PathVariable  String plateNo){

//        Car cardelete = carServiceInterface.findById(plateNo);
        carServiceInterface.deleteCar(plateNo);
        return  new ResponseEntity<>(HttpStatus.NO_CONTENT);

}
}

