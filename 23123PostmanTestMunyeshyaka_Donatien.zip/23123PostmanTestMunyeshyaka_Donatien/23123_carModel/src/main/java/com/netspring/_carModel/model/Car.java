package com.netspring._carModel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
// this @Data is used for to replace @AllArgsConstructor, @NoAllConstructor,@Getter and Setter
// WHEN YOU NEED TO MINIMIZE TH ENUMBER OF CODE THIS IS THE WAY USED FOR TO FIX IT
//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor

@Entity
@Table(name="cars")
public class Car {
    @Id
    private String plateNo;
    @Column(name="car_name")
    private String carName;
    @Column(name="car_model")
    private String carModel;
    @Column(name="car_type")
    private String carType;

    public Car() {
    }

    public Car(String plateNo, String carName, String carModel, String carType) {
        this.plateNo = plateNo;
        this.carName = carName;
        this.carModel = carModel;
        this.carType = carType;
    }

    public String getPlateNo() {
        return plateNo;
    }

    public void setPlateNo(String plateNo) {
        this.plateNo = plateNo;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }
}
