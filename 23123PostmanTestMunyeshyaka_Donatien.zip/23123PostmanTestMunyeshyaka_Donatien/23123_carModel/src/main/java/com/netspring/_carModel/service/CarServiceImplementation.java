package com.netspring._carModel.service;

import com.netspring._carModel.model.Car;
import com.netspring._carModel.repository.CarDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CarServiceImplementation implements CarServiceInterface{
   @Autowired
    CarDao carDao;
    @Override
    public Car saveCar(Car car) {
        return carDao.save(car);
    }

    @Override
    public List<Car> findAll() {
        return carDao.findAll();
    }

    @Override
    public Car findById(String plateNo) {
        return carDao.findById(plateNo).orElse(null);
    }

    @Override
    public Car updateCar(Car car) {
        Car carsaved = carDao.findById(car.getPlateNo()).orElse(null);
        if(carsaved!=null){
            Car crs = new Car();
            crs.setPlateNo(car.getPlateNo());
            crs.setCarName(car.getCarName());
            crs.setCarModel(car.getCarModel());
            crs.setCarType(car.getCarType());
            return carDao.save(crs);

        }

        return null;
    }

    @Override
    public void deleteCar(String plateNo) {
        Car deletedcar = carDao.findById(plateNo).orElse(null);
        if(deletedcar!=null){
            carDao.deleteById(plateNo);
        }

    }
}
